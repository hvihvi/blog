import * as React from 'react';

export const $NAME = () => {
  return <></>;
};